package competitorEntries.bindingModels;

public class CompetitorBindingModel {
    // TODO: Implement me
}
