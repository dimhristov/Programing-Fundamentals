package competitorEntries.entities;

import javax.persistence.*;

@Entity
@Table(name = "competitors")
public class Competitor {
    // TODO: Implement me
}
